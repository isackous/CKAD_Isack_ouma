# DOIT — Todo App

A full-stack Todo application built with:
- **Frontend**: Vue 3 + Vite (served by Nginx)
- **Backend**: Spring Boot 3 (Java 17)
- **Database**: PostgreSQL 16
- **Orchestration**: Docker Compose

---

## 🚀 Quick Start

### Prerequisites
- [Docker](https://docs.docker.com/get-docker/) installed
- [Docker Compose](https://docs.docker.com/compose/install/) installed

### Run the App

```bash
# Clone / navigate to the project folder
cd todo-app

# Build images and start all services
docker compose up --build

# To run in the background
docker compose up --build -d
```

Then open your browser at: **http://localhost**

---

## 🏗️ Architecture

```
Browser (http://localhost)
        │
        ▼
  ┌─────────────┐
  │   Nginx     │  Port 80  (serves Vue SPA)
  │  Frontend   │──── /api/* proxied to backend
  └─────────────┘
        │
        ▼
  ┌─────────────┐
  │ Spring Boot │  Port 8080  (REST API)
  │   Backend   │
  └─────────────┘
        │
        ▼
  ┌─────────────┐
  │ PostgreSQL  │  Port 5432
  │   Database  │
  └─────────────┘
```

## 📡 API Endpoints

| Method   | Endpoint                  | Description           |
|----------|---------------------------|-----------------------|
| GET      | /api/todos                | Get all todos         |
| GET      | /api/todos/:id            | Get todo by ID        |
| POST     | /api/todos                | Create new todo       |
| PUT      | /api/todos/:id            | Update todo           |
| PATCH    | /api/todos/:id/toggle     | Toggle completed      |
| DELETE   | /api/todos/:id            | Delete todo           |

## 🛑 Stop the App

```bash
docker compose down

# To also remove the database volume
docker compose down -v
```

## 🔧 Development

To rebuild only one service after changes:

```bash
docker compose up --build backend
docker compose up --build frontend
```

---

## 📁 Project Structure

```
todo-app/
├── docker-compose.yml
├── backend/
│   ├── Dockerfile
│   ├── pom.xml
│   └── src/main/java/com/todo/
│       ├── TodoApplication.java
│       ├── controller/TodoController.java
│       ├── model/Todo.java
│       ├── repository/TodoRepository.java
│       └── service/TodoService.java
└── frontend/
    ├── Dockerfile
    ├── nginx.conf
    ├── index.html
    ├── package.json
    └── src/
        ├── main.js
        ├── App.vue
        ├── assets/main.css
        └── components/TodoCard.vue
```
