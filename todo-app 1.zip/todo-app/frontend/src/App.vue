<template>
  <div class="app">
    <!-- Background grid -->
    <div class="bg-grid"></div>

    <!-- Header -->
    <header class="header">
      <div class="header-inner">
        <div class="logo">
          <span class="logo-icon">◈</span>
          <span class="logo-text">DOIT</span>
          <span class="logo-tag">task matrix</span>
        </div>
        <div class="header-stats">
          <div class="stat">
            <span class="stat-num">{{ todos.length }}</span>
            <span class="stat-label">total</span>
          </div>
          <div class="stat-divider"></div>
          <div class="stat">
            <span class="stat-num accent">{{ completedCount }}</span>
            <span class="stat-label">done</span>
          </div>
          <div class="stat-divider"></div>
          <div class="stat">
            <span class="stat-num">{{ pendingCount }}</span>
            <span class="stat-label">pending</span>
          </div>
        </div>
      </div>
    </header>

    <main class="main">
      <!-- Add Form -->
      <section class="add-section">
        <div class="section-label">
          <span class="label-num">01</span>
          <span>NEW TASK</span>
        </div>
        <form class="add-form" @submit.prevent="handleAddTodo">
          <div class="form-row">
            <div class="input-wrap flex-1">
              <input
                v-model="newTodo.title"
                class="input"
                placeholder="What needs to be done?"
                required
              />
            </div>
            <div class="input-wrap">
              <select v-model="newTodo.priority" class="select">
                <option value="LOW">Low</option>
                <option value="MEDIUM">Medium</option>
                <option value="HIGH">High</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="input-wrap flex-1">
              <textarea
                v-model="newTodo.description"
                class="input textarea"
                placeholder="Add a description (optional)..."
                rows="2"
              ></textarea>
            </div>
            <button type="submit" class="btn-add" :class="{ loading: adding }">
              <span v-if="!adding">+ ADD</span>
              <span v-else class="spinner-inline"></span>
            </button>
          </div>
        </form>
      </section>

      <!-- Filter Bar -->
      <section class="filter-bar">
        <div class="section-label">
          <span class="label-num">02</span>
          <span>TASK LIST</span>
        </div>
        <div class="filters">
          <button
            v-for="f in filters"
            :key="f.value"
            class="filter-btn"
            :class="{ active: activeFilter === f.value }"
            @click="activeFilter = f.value"
          >{{ f.label }}</button>
          <div class="filter-count">{{ filteredTodos.length }} tasks</div>
        </div>
      </section>

      <!-- Loading -->
      <div v-if="loading" class="loading-state">
        <div class="spinner"></div>
        <span>Loading tasks...</span>
      </div>

      <!-- Error -->
      <div v-else-if="error" class="error-state">
        <span class="error-icon">⚠</span>
        <span>{{ error }}</span>
        <button class="btn-retry" @click="fetchTodos">Retry</button>
      </div>

      <!-- Empty -->
      <div v-else-if="filteredTodos.length === 0" class="empty-state">
        <div class="empty-icon">◎</div>
        <div class="empty-title">No tasks here</div>
        <div class="empty-sub">{{ activeFilter === 'all' ? 'Add your first task above' : 'Switch filters or add new tasks' }}</div>
      </div>

      <!-- Todo List -->
      <div v-else class="todo-list">
        <transition-group name="task" tag="div">
          <TodoCard
            v-for="todo in filteredTodos"
            :key="todo.id"
            :todo="todo"
            @toggle="toggleTodo"
            @edit="openEdit"
            @delete="deleteTodo"
          />
        </transition-group>
      </div>
    </main>

    <!-- Edit Modal -->
    <transition name="modal">
      <div v-if="editingTodo" class="modal-overlay" @click.self="closeEdit">
        <div class="modal">
          <div class="modal-header">
            <span class="modal-title">EDIT TASK</span>
            <button class="btn-close" @click="closeEdit">✕</button>
          </div>
          <form @submit.prevent="handleUpdateTodo" class="modal-form">
            <label class="form-label">Title</label>
            <input v-model="editForm.title" class="input" required />

            <label class="form-label">Description</label>
            <textarea v-model="editForm.description" class="input textarea" rows="3"></textarea>

            <label class="form-label">Priority</label>
            <select v-model="editForm.priority" class="select full">
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
            </select>

            <label class="form-label checkbox-label">
              <input type="checkbox" v-model="editForm.completed" class="checkbox" />
              <span>Mark as completed</span>
            </label>

            <div class="modal-actions">
              <button type="button" class="btn-cancel" @click="closeEdit">Cancel</button>
              <button type="submit" class="btn-save" :class="{ loading: saving }">
                <span v-if="!saving">Save Changes</span>
                <span v-else class="spinner-inline"></span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </transition>

    <!-- Toast notification -->
    <transition name="toast">
      <div v-if="toast.show" class="toast" :class="toast.type">
        {{ toast.message }}
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'
import TodoCard from './components/TodoCard.vue'

const API = '/api/todos'

const todos = ref([])
const loading = ref(true)
const error = ref(null)
const adding = ref(false)
const saving = ref(false)
const activeFilter = ref('all')
const editingTodo = ref(null)
const toast = ref({ show: false, message: '', type: 'success' })

const newTodo = ref({ title: '', description: '', priority: 'MEDIUM' })
const editForm = ref({})

const filters = [
  { label: 'All', value: 'all' },
  { label: 'Pending', value: 'pending' },
  { label: 'Done', value: 'done' },
  { label: '🔴 High', value: 'high' },
  { label: '🟡 Medium', value: 'medium' },
  { label: '🟢 Low', value: 'low' },
]

const filteredTodos = computed(() => {
  switch (activeFilter.value) {
    case 'pending': return todos.value.filter(t => !t.completed)
    case 'done': return todos.value.filter(t => t.completed)
    case 'high': return todos.value.filter(t => t.priority === 'HIGH')
    case 'medium': return todos.value.filter(t => t.priority === 'MEDIUM')
    case 'low': return todos.value.filter(t => t.priority === 'LOW')
    default: return todos.value
  }
})

const completedCount = computed(() => todos.value.filter(t => t.completed).length)
const pendingCount = computed(() => todos.value.filter(t => !t.completed).length)

async function fetchTodos() {
  loading.value = true
  error.value = null
  try {
    const res = await axios.get(API)
    todos.value = res.data
  } catch (e) {
    error.value = 'Could not connect to server. Is the backend running?'
  } finally {
    loading.value = false
  }
}

async function handleAddTodo() {
  if (!newTodo.value.title.trim()) return
  adding.value = true
  try {
    const res = await axios.post(API, newTodo.value)
    todos.value.unshift(res.data)
    newTodo.value = { title: '', description: '', priority: 'MEDIUM' }
    showToast('Task added!', 'success')
  } catch {
    showToast('Failed to add task', 'error')
  } finally {
    adding.value = false
  }
}

async function toggleTodo(todo) {
  try {
    const res = await axios.patch(`${API}/${todo.id}/toggle`)
    const idx = todos.value.findIndex(t => t.id === todo.id)
    if (idx !== -1) todos.value[idx] = res.data
  } catch {
    showToast('Failed to update task', 'error')
  }
}

function openEdit(todo) {
  editingTodo.value = todo
  editForm.value = { ...todo }
}

function closeEdit() {
  editingTodo.value = null
}

async function handleUpdateTodo() {
  saving.value = true
  try {
    const res = await axios.put(`${API}/${editingTodo.value.id}`, editForm.value)
    const idx = todos.value.findIndex(t => t.id === editingTodo.value.id)
    if (idx !== -1) todos.value[idx] = res.data
    closeEdit()
    showToast('Task updated!', 'success')
  } catch {
    showToast('Failed to update task', 'error')
  } finally {
    saving.value = false
  }
}

async function deleteTodo(todo) {
  try {
    await axios.delete(`${API}/${todo.id}`)
    todos.value = todos.value.filter(t => t.id !== todo.id)
    showToast('Task deleted', 'success')
  } catch {
    showToast('Failed to delete task', 'error')
  }
}

function showToast(message, type = 'success') {
  toast.value = { show: true, message, type }
  setTimeout(() => { toast.value.show = false }, 3000)
}

onMounted(fetchTodos)
</script>

<style scoped>
.app {
  min-height: 100vh;
  position: relative;
}

.bg-grid {
  position: fixed;
  inset: 0;
  background-image:
    linear-gradient(rgba(200,240,74,0.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(200,240,74,0.03) 1px, transparent 1px);
  background-size: 40px 40px;
  pointer-events: none;
  z-index: 0;
}

/* Header */
.header {
  position: sticky;
  top: 0;
  z-index: 100;
  background: rgba(10,10,15,0.85);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--border);
}

.header-inner {
  max-width: 900px;
  margin: 0 auto;
  padding: 16px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.logo {
  display: flex;
  align-items: center;
  gap: 10px;
}

.logo-icon {
  color: var(--accent);
  font-size: 22px;
}

.logo-text {
  font-size: 22px;
  font-weight: 800;
  letter-spacing: 0.12em;
  color: var(--text);
}

.logo-tag {
  font-family: var(--font-mono);
  font-size: 10px;
  color: var(--text-muted);
  letter-spacing: 0.1em;
  background: var(--surface2);
  padding: 3px 8px;
  border-radius: 20px;
  border: 1px solid var(--border);
}

.header-stats {
  display: flex;
  align-items: center;
  gap: 16px;
}

.stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
}

.stat-num {
  font-size: 18px;
  font-weight: 700;
  font-family: var(--font-mono);
  color: var(--text);
}

.stat-num.accent { color: var(--accent); }
.stat-label {
  font-size: 9px;
  font-family: var(--font-mono);
  color: var(--text-muted);
  letter-spacing: 0.1em;
  text-transform: uppercase;
}

.stat-divider {
  width: 1px;
  height: 28px;
  background: var(--border);
}

/* Main */
.main {
  max-width: 900px;
  margin: 0 auto;
  padding: 32px 24px 80px;
  position: relative;
  z-index: 1;
}

/* Section Labels */
.section-label {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 11px;
  font-family: var(--font-mono);
  letter-spacing: 0.15em;
  color: var(--text-muted);
  margin-bottom: 14px;
}

.label-num {
  color: var(--accent);
  font-weight: 500;
}

/* Add Form */
.add-section {
  margin-bottom: 40px;
}

.add-form {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.form-row {
  display: flex;
  gap: 12px;
  align-items: flex-start;
}

.input-wrap { display: flex; flex-direction: column; }
.flex-1 { flex: 1; }

.input {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text);
  padding: 12px 14px;
  font-size: 14px;
  font-family: var(--font-main);
  width: 100%;
  transition: border-color 0.2s, box-shadow 0.2s;
  outline: none;
  resize: none;
}

.input:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-dim);
}

.input::placeholder { color: var(--text-muted); }
.textarea { min-height: 64px; }

.select {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text);
  padding: 12px 14px;
  font-size: 14px;
  font-family: var(--font-main);
  outline: none;
  cursor: pointer;
  transition: border-color 0.2s;
}

.select:focus { border-color: var(--accent); }
.select.full { width: 100%; }

.btn-add {
  background: var(--accent);
  color: #0a0a0f;
  border: none;
  border-radius: var(--radius-sm);
  padding: 0 28px;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.08em;
  min-width: 100px;
  align-self: stretch;
  transition: background 0.2s, transform 0.1s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-add:hover { background: #d4f55a; transform: translateY(-1px); }
.btn-add:active { transform: translateY(0); }

/* Filter Bar */
.filter-bar { margin-bottom: 20px; }

.filters {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.filter-btn {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 20px;
  color: var(--text-dim);
  padding: 6px 14px;
  font-size: 12px;
  font-weight: 500;
  transition: all 0.2s;
}

.filter-btn:hover {
  border-color: var(--accent);
  color: var(--text);
}

.filter-btn.active {
  background: var(--accent-dim);
  border-color: var(--accent);
  color: var(--accent);
}

.filter-count {
  margin-left: auto;
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--text-muted);
}

/* States */
.loading-state, .error-state, .empty-state {
  text-align: center;
  padding: 60px 20px;
  color: var(--text-muted);
}

.spinner {
  width: 36px;
  height: 36px;
  border: 3px solid var(--border);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
  margin: 0 auto 16px;
}

@keyframes spin { to { transform: rotate(360deg); } }

.spinner-inline {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid rgba(0,0,0,0.3);
  border-top-color: #0a0a0f;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

.error-state { color: var(--red); }
.error-icon { font-size: 28px; display: block; margin-bottom: 10px; }
.btn-retry {
  margin-top: 12px;
  background: var(--surface2);
  border: 1px solid var(--border);
  color: var(--text);
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 13px;
}

.empty-icon {
  font-size: 48px;
  color: var(--border);
  margin-bottom: 12px;
}

.empty-title {
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 6px;
  color: var(--text-dim);
}

.empty-sub { font-size: 13px; }

/* Todo List */
.todo-list { display: flex; flex-direction: column; gap: 10px; }

.task-enter-active, .task-leave-active { transition: all 0.3s ease; }
.task-enter-from { opacity: 0; transform: translateY(-12px); }
.task-leave-to { opacity: 0; transform: translateX(20px); }

/* Modal */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.7);
  backdrop-filter: blur(4px);
  z-index: 200;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.modal {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  width: 100%;
  max-width: 520px;
  padding: 28px;
  box-shadow: 0 25px 80px rgba(0,0,0,0.6);
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 24px;
}

.modal-title {
  font-size: 13px;
  font-family: var(--font-mono);
  letter-spacing: 0.15em;
  color: var(--accent);
}

.btn-close {
  background: none;
  border: none;
  color: var(--text-muted);
  font-size: 16px;
  padding: 4px 8px;
  border-radius: 4px;
  transition: color 0.2s, background 0.2s;
}

.btn-close:hover { color: var(--text); background: var(--surface2); }

.modal-form { display: flex; flex-direction: column; gap: 14px; }

.form-label {
  font-size: 11px;
  font-family: var(--font-mono);
  letter-spacing: 0.1em;
  color: var(--text-muted);
  text-transform: uppercase;
  margin-bottom: -6px;
}

.checkbox-label {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  font-family: var(--font-main);
  font-size: 14px;
  color: var(--text-dim);
}

.checkbox {
  width: 16px;
  height: 16px;
  accent-color: var(--accent);
}

.modal-actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
  margin-top: 8px;
}

.btn-cancel {
  background: var(--surface2);
  border: 1px solid var(--border);
  color: var(--text-dim);
  padding: 10px 20px;
  border-radius: var(--radius-sm);
  font-size: 13px;
  font-weight: 500;
  transition: all 0.2s;
}

.btn-cancel:hover { border-color: var(--text-dim); color: var(--text); }

.btn-save {
  background: var(--accent);
  border: none;
  color: #0a0a0f;
  padding: 10px 24px;
  border-radius: var(--radius-sm);
  font-size: 13px;
  font-weight: 700;
  min-width: 120px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.2s;
}

.btn-save:hover { background: #d4f55a; }

/* Modal transitions */
.modal-enter-active, .modal-leave-active { transition: opacity 0.25s ease; }
.modal-enter-from, .modal-leave-to { opacity: 0; }
.modal-enter-active .modal, .modal-leave-active .modal { transition: transform 0.25s ease; }
.modal-enter-from .modal { transform: scale(0.95) translateY(10px); }
.modal-leave-to .modal { transform: scale(0.95) translateY(10px); }

/* Toast */
.toast {
  position: fixed;
  bottom: 28px;
  left: 50%;
  transform: translateX(-50%);
  padding: 12px 24px;
  border-radius: 30px;
  font-size: 13px;
  font-weight: 600;
  z-index: 300;
  letter-spacing: 0.03em;
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
}

.toast.success { background: var(--accent); color: #0a0a0f; }
.toast.error { background: var(--red); color: white; }

.toast-enter-active, .toast-leave-active { transition: all 0.3s ease; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translateX(-50%) translateY(20px); }
</style>
