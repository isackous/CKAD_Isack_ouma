<template>
  <div class="todo-card" :class="{ completed: todo.completed, [`priority-${todo.priority.toLowerCase()}`]: true }">
    <div class="card-left">
      <button class="check-btn" :class="{ checked: todo.completed }" @click="$emit('toggle', todo)">
        <span v-if="todo.completed">✓</span>
      </button>
    </div>

    <div class="card-body">
      <div class="card-top">
        <span class="todo-title" :class="{ strikethrough: todo.completed }">{{ todo.title }}</span>
        <span class="priority-badge" :class="todo.priority.toLowerCase()">{{ todo.priority }}</span>
      </div>
      <p v-if="todo.description" class="todo-desc">{{ todo.description }}</p>
      <div class="card-meta">
        <span class="meta-date">{{ formatDate(todo.createdAt) }}</span>
        <span v-if="todo.completed" class="meta-done">✓ completed</span>
      </div>
    </div>

    <div class="card-actions">
      <button class="action-btn edit" @click="$emit('edit', todo)" title="Edit">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
        </svg>
      </button>
      <button class="action-btn delete" @click="confirmDelete" title="Delete">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="3 6 5 6 21 6"/>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
        </svg>
      </button>
    </div>

    <!-- Delete confirm -->
    <div v-if="showConfirm" class="confirm-overlay">
      <span class="confirm-text">Delete this task?</span>
      <div class="confirm-actions">
        <button class="confirm-no" @click="showConfirm = false">No</button>
        <button class="confirm-yes" @click="handleDelete">Yes, delete</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const props = defineProps({ todo: Object })
const emit = defineEmits(['toggle', 'edit', 'delete'])
const showConfirm = ref(false)

function confirmDelete() { showConfirm.value = true }
function handleDelete() {
  showConfirm.value = false
  emit('delete', props.todo)
}

function formatDate(dateStr) {
  if (!dateStr) return ''
  const d = new Date(dateStr)
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}
</script>

<style scoped>
.todo-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 16px;
  display: flex;
  align-items: flex-start;
  gap: 14px;
  transition: border-color 0.2s, transform 0.15s, box-shadow 0.2s;
  position: relative;
  overflow: hidden;
}

.todo-card::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 3px;
  border-radius: 3px 0 0 3px;
}

.todo-card.priority-high::before { background: var(--high); }
.todo-card.priority-medium::before { background: var(--medium); }
.todo-card.priority-low::before { background: var(--low); }

.todo-card:hover {
  border-color: rgba(200,240,74,0.25);
  box-shadow: 0 4px 20px rgba(0,0,0,0.3);
  transform: translateY(-1px);
}

.todo-card.completed {
  opacity: 0.6;
}

.card-left { flex-shrink: 0; }

.check-btn {
  width: 22px;
  height: 22px;
  border-radius: 6px;
  border: 2px solid var(--border);
  background: transparent;
  color: #0a0a0f;
  font-size: 12px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
  margin-top: 2px;
}

.check-btn:hover {
  border-color: var(--accent);
  background: var(--accent-dim);
}

.check-btn.checked {
  background: var(--accent);
  border-color: var(--accent);
  color: #0a0a0f;
}

.card-body { flex: 1; min-width: 0; }

.card-top {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  margin-bottom: 4px;
}

.todo-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--text);
  transition: color 0.2s;
}

.todo-title.strikethrough {
  text-decoration: line-through;
  color: var(--text-muted);
}

.priority-badge {
  font-size: 9px;
  font-family: var(--font-mono);
  font-weight: 500;
  letter-spacing: 0.1em;
  padding: 2px 8px;
  border-radius: 10px;
}

.priority-badge.high { background: rgba(248,113,113,0.15); color: var(--high); }
.priority-badge.medium { background: rgba(251,191,36,0.15); color: var(--medium); }
.priority-badge.low { background: rgba(74,222,128,0.15); color: var(--low); }

.todo-desc {
  font-size: 13px;
  color: var(--text-dim);
  margin-bottom: 8px;
  white-space: pre-wrap;
  line-height: 1.5;
}

.card-meta {
  display: flex;
  gap: 12px;
  align-items: center;
}

.meta-date {
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--text-muted);
}

.meta-done {
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--accent);
}

.card-actions {
  display: flex;
  gap: 6px;
  flex-shrink: 0;
}

.action-btn {
  width: 32px;
  height: 32px;
  border-radius: var(--radius-sm);
  border: 1px solid var(--border);
  background: transparent;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}

.action-btn.edit { color: var(--blue); }
.action-btn.edit:hover { background: rgba(96,165,250,0.15); border-color: var(--blue); }

.action-btn.delete { color: var(--red); }
.action-btn.delete:hover { background: rgba(255,92,92,0.15); border-color: var(--red); }

/* Confirm */
.confirm-overlay {
  position: absolute;
  inset: 0;
  background: rgba(10,10,15,0.92);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  border-radius: var(--radius);
  backdrop-filter: blur(2px);
}

.confirm-text {
  font-size: 13px;
  font-weight: 600;
  color: var(--text);
}

.confirm-actions { display: flex; gap: 8px; }

.confirm-no {
  background: var(--surface2);
  border: 1px solid var(--border);
  color: var(--text-dim);
  padding: 7px 16px;
  border-radius: var(--radius-sm);
  font-size: 12px;
  font-weight: 600;
  transition: all 0.2s;
}

.confirm-no:hover { border-color: var(--text-dim); color: var(--text); }

.confirm-yes {
  background: var(--red);
  border: none;
  color: white;
  padding: 7px 16px;
  border-radius: var(--radius-sm);
  font-size: 12px;
  font-weight: 700;
  transition: background 0.2s;
}

.confirm-yes:hover { background: #ff4040; }
</style>
